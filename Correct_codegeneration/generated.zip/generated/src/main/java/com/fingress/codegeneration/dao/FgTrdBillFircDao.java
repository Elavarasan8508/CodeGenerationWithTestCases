package com.bsit.codegeneration.dao;

import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.config.RegisterRowMapper;
import com.bsit.codegeneration.record.FgTrdBillFirc;
import com.bsit.codegeneration.mapper.FgTrdBillFircMapper;
import java.util.*;

@RegisterRowMapper(FgTrdBillFircMapper.class)
public interface FgTrdBillFircDao {

    @SqlQuery("SELECT * FROM FG_TRD_BILL_FIRC")
    public List<FgTrdBillFirc> findAll();

    @SqlQuery("SELECT * FROM FG_TRD_BILL_FIRC WHERE id = :id")
    public Optional<FgTrdBillFirc> findById(@Bind("id") String id);

    @SqlUpdate("INSERT INTO FG_TRD_BILL_FIRC(ID, REFERENCE_ID, TYPE_CODE, SUB_TYPE_CODE, ACTIVE_CODE, STAGE_CODE, STATUS_CODE, CREATED_ON, CREATED_BY, LAST_UPDATED_ON, LAST_UPDATED_BY, LAST_AUTHORISED_ON, LAST_AUTHORISED_BY, TEMPLATE, IS_TEMPLATE, FIRC_NO, FIRC_DATE, FIRC_CCY, FIRC_AMT, FIRC_UTIL_AMT, FIRC_OS_AMT, AD_CODE, IE_CODE, REMITTER_NAME, REMITTER_COUNTRY, REMIT_BANK_COUNTRY) VALUES (:ID, :REFERENCE_ID, :TYPE_CODE, :SUB_TYPE_CODE, :ACTIVE_CODE, :STAGE_CODE, :STATUS_CODE, :CREATED_ON, :CREATED_BY, :LAST_UPDATED_ON, :LAST_UPDATED_BY, :LAST_AUTHORISED_ON, :LAST_AUTHORISED_BY, :TEMPLATE, :IS_TEMPLATE, :FIRC_NO, :FIRC_DATE, :FIRC_CCY, :FIRC_AMT, :FIRC_UTIL_AMT, :FIRC_OS_AMT, :AD_CODE, :IE_CODE, :REMITTER_NAME, :REMITTER_COUNTRY, :REMIT_BANK_COUNTRY)")
    @GetGeneratedKeys()
    public String insert(@BindBean() FgTrdBillFirc entity);

    @SqlQuery("UPDATE FG_TRD_BILL_FIRC SET ID = :ID, REFERENCE_ID = :REFERENCE_ID, TYPE_CODE = :TYPE_CODE, SUB_TYPE_CODE = :SUB_TYPE_CODE, ACTIVE_CODE = :ACTIVE_CODE, STAGE_CODE = :STAGE_CODE, STATUS_CODE = :STATUS_CODE, CREATED_ON = :CREATED_ON, CREATED_BY = :CREATED_BY, LAST_UPDATED_ON = :LAST_UPDATED_ON, LAST_UPDATED_BY = :LAST_UPDATED_BY, LAST_AUTHORISED_ON = :LAST_AUTHORISED_ON, LAST_AUTHORISED_BY = :LAST_AUTHORISED_BY, TEMPLATE = :TEMPLATE, IS_TEMPLATE = :IS_TEMPLATE, FIRC_NO = :FIRC_NO, FIRC_DATE = :FIRC_DATE, FIRC_CCY = :FIRC_CCY, FIRC_AMT = :FIRC_AMT, FIRC_UTIL_AMT = :FIRC_UTIL_AMT, FIRC_OS_AMT = :FIRC_OS_AMT, AD_CODE = :AD_CODE, IE_CODE = :IE_CODE, REMITTER_NAME = :REMITTER_NAME, REMITTER_COUNTRY = :REMITTER_COUNTRY, REMIT_BANK_COUNTRY = :REMIT_BANK_COUNTRY WHERE id = :id")
    public int update(@BindBean() FgTrdBillFirc entity);

    @SqlQuery("DELETE FROM FG_TRD_BILL_FIRC WHERE id = :id")
    public int delete(@Bind("id") String id);
}
