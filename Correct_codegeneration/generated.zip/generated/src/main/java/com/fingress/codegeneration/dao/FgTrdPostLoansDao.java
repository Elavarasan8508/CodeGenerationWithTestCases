package com.bsit.codegeneration.dao;

import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.config.RegisterRowMapper;
import com.bsit.codegeneration.record.FgTrdPostLoans;
import com.bsit.codegeneration.mapper.FgTrdPostLoansMapper;
import java.util.*;

@RegisterRowMapper(FgTrdPostLoansMapper.class)
public interface FgTrdPostLoansDao {

    @SqlQuery("SELECT * FROM FG_TRD_POST_LOANS")
    public List<FgTrdPostLoans> findAll();

    @SqlQuery("SELECT * FROM FG_TRD_POST_LOANS WHERE id = :id")
    public Optional<FgTrdPostLoans> findById(@Bind("id") String id);

    @SqlUpdate("INSERT INTO FG_TRD_POST_LOANS(ID, REFERENCE_ID, TYPE_CODE, SUB_TYPE_CODE, ACTIVE_CODE, STAGE_CODE, STATUS_CODE, CREATED_ON, CREATED_BY, LAST_UPDATED_ON, LAST_UPDATED_BY, LAST_AUTHORISED_ON, LAST_AUTHORISED_BY, TEMPLATE, IS_TEMPLATE, POST_LOAN_REF_ID, TXN_REF_ID, LOAN_REF_ID, CUR_CODE, PRINCIPAL_OUTSTANDING, DSP_AMT, EQU_DSP_AMT, COLLECT_SHORT, ACC_NO, PARENT_REF_ID, PARENT_VERSION_ID, IR_REFERENCE_ID, APPLICANT_PARTY, BILL_REF_ID) VALUES (:ID, :REFERENCE_ID, :TYPE_CODE, :SUB_TYPE_CODE, :ACTIVE_CODE, :STAGE_CODE, :STATUS_CODE, :CREATED_ON, :CREATED_BY, :LAST_UPDATED_ON, :LAST_UPDATED_BY, :LAST_AUTHORISED_ON, :LAST_AUTHORISED_BY, :TEMPLATE, :IS_TEMPLATE, :POST_LOAN_REF_ID, :TXN_REF_ID, :LOAN_REF_ID, :CUR_CODE, :PRINCIPAL_OUTSTANDING, :DSP_AMT, :EQU_DSP_AMT, :COLLECT_SHORT, :ACC_NO, :PARENT_REF_ID, :PARENT_VERSION_ID, :IR_REFERENCE_ID, :APPLICANT_PARTY, :BILL_REF_ID)")
    @GetGeneratedKeys()
    public String insert(@BindBean() FgTrdPostLoans entity);

    @SqlQuery("UPDATE FG_TRD_POST_LOANS SET ID = :ID, REFERENCE_ID = :REFERENCE_ID, TYPE_CODE = :TYPE_CODE, SUB_TYPE_CODE = :SUB_TYPE_CODE, ACTIVE_CODE = :ACTIVE_CODE, STAGE_CODE = :STAGE_CODE, STATUS_CODE = :STATUS_CODE, CREATED_ON = :CREATED_ON, CREATED_BY = :CREATED_BY, LAST_UPDATED_ON = :LAST_UPDATED_ON, LAST_UPDATED_BY = :LAST_UPDATED_BY, LAST_AUTHORISED_ON = :LAST_AUTHORISED_ON, LAST_AUTHORISED_BY = :LAST_AUTHORISED_BY, TEMPLATE = :TEMPLATE, IS_TEMPLATE = :IS_TEMPLATE, POST_LOAN_REF_ID = :POST_LOAN_REF_ID, TXN_REF_ID = :TXN_REF_ID, LOAN_REF_ID = :LOAN_REF_ID, CUR_CODE = :CUR_CODE, PRINCIPAL_OUTSTANDING = :PRINCIPAL_OUTSTANDING, DSP_AMT = :DSP_AMT, EQU_DSP_AMT = :EQU_DSP_AMT, COLLECT_SHORT = :COLLECT_SHORT, ACC_NO = :ACC_NO, PARENT_REF_ID = :PARENT_REF_ID, PARENT_VERSION_ID = :PARENT_VERSION_ID, IR_REFERENCE_ID = :IR_REFERENCE_ID, APPLICANT_PARTY = :APPLICANT_PARTY, BILL_REF_ID = :BILL_REF_ID WHERE id = :id")
    public int update(@BindBean() FgTrdPostLoans entity);

    @SqlQuery("DELETE FROM FG_TRD_POST_LOANS WHERE id = :id")
    public int delete(@Bind("id") String id);
}
